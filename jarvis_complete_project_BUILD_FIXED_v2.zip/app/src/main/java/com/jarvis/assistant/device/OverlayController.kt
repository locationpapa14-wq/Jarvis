package com.jarvis.assistant.device

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import com.jarvis.assistant.ui.overlay.JarvisEdgeView
import com.jarvis.assistant.ui.overlay.JarvisOrbView
import com.jarvis.assistant.ui.overlay.OverlayState

class OverlayController(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var orb: JarvisOrbView? = null
    private var edge: JarvisEdgeView? = null
    private var orbLp: WindowManager.LayoutParams? = null
    var onOrbTap: () -> Unit = {}
    var edgeIntensity = 0.8f
    var edgeDurationMs = 0L // 0 = until stopped

    private val type get() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    fun canDraw() = Settings.canDrawOverlays(ctx)

    fun showOrb(): DeviceActionResult {
        if (!canDraw()) return DeviceActionResult.needsEnablement("Allow \"Display over other apps\" for JARVIS.", Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
        main.post {
            if (orb != null) return@post
            val size = (ctx.resources.displayMetrics.density * 64).toInt()
            val lp = WindowManager.LayoutParams(size, size, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 300 }
            val v = JarvisOrbView(ctx, { onOrbTap() }) { nx, ny -> lp.x = nx; lp.y = ny; wm.updateViewLayout(orb, lp) }
            orbLp = lp; orb = v; wm.addView(v, lp)
        }
        return DeviceActionResult.success("Overlay shown.")
    }

    fun hideOrb(): DeviceActionResult {
        main.post { orb?.let { runCatching { wm.removeView(it) } }; orb = null }
        return DeviceActionResult.success("Overlay hidden.")
    }

    fun startEdge(): DeviceActionResult {
        if (!canDraw()) return DeviceActionResult.needsEnablement("Allow \"Display over other apps\" for JARVIS.", Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
        main.post {
            if (edge == null) {
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT)
                edge = JarvisEdgeView(ctx).also { it.intensity = edgeIntensity; wm.addView(it, lp) }
            }
            if (edgeDurationMs > 0) main.postDelayed({ stopEdge() }, edgeDurationMs)
        }
        return DeviceActionResult.success("Edge lighting on.")
    }

    fun stopEdge(): DeviceActionResult {
        main.post { edge?.let { runCatching { wm.removeView(it) } }; edge = null }
        return DeviceActionResult.success("Edge lighting off.")
    }

    fun setState(s: OverlayState) = main.post { orb?.state = s; edge?.state = s }

    fun removeAll() { hideOrb(); stopEdge() }
}
